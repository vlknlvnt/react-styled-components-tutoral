# Huddle Landing Page (React & Styled Components)

Project from my styled components crash course

## Usage

```
npm install
npm start
```
